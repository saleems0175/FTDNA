﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Data.Models
{
    [Table("Samples")]
    public class Sample
    {
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        [Required, Key]
        public int SampleId { get; set; }

        [StringLength(30)]
        public string Barcode { get; set; }

        public DateTime? CreatedAt { get; set; }

        public int? CreatedBy { get; set; }

        public int? StatusId { get; set; }

        [ForeignKey("StatusId")]
        public virtual Status Status { get; set; }

        [ForeignKey("CreatedBy")]
        public virtual User User { get; set; }
    }
}
