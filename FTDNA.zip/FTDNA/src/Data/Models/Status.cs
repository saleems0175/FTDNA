﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Data.Models
{
    [Table("Status")]
    public class Status
    {

        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        [Required, Key]
        public int StatusId { get; set; }

        [Column("Status")]
        [StringLength(30)]
        public string StatusDescription { get; set; }
    }
}
