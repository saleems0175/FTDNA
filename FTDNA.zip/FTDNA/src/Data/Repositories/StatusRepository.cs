﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Data.Models;

namespace Data.Repositories
{

    public interface IStatusRepository
    {
        void LoadData();
        List<Status> GetAllStatuses();
    }
    public class StatusRepository : BaseRepository, IStatusRepository
    {
        public StatusRepository(FTDNAContext context) : base("Statuses.txt", context)
        {
        }

        public List<Status> GetAllStatuses()
        {
            return context.Status.ToList();
        }

        public override void LoadData()
        {
            if (!base.context.Status.Any())
            {
                var readCsv = File.ReadAllText(base.filePath);
                var records = readCsv.Split('\n');
                for (int i = 0; i < records.Count(); i++)
                {
                    if (i != 0)
                    {
                        var record = records[i].TrimEnd('\r');
                        var splitResults = record.Split(',');

                        if (splitResults.Count() == 2)
                        {
                            Status status = new Status
                            {
                                StatusId = int.Parse(splitResults[0]),
                                StatusDescription = splitResults[1]
                            };

                            base.context.Status.Add(status);
                        }
                    }
                }

                base.context.SaveChanges();
            }
        }
    }
}
