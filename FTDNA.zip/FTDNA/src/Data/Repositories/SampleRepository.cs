﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Data.Models;
using Microsoft.EntityFrameworkCore;

namespace Data.Repositories
{

    public interface ISampleRepostitory
    {
        void Add(Sample sample);
        List<Sample> GetAllSamples();

        List<Sample> GetSampleByUserNameSearch(string userNameSearchString);

        List<Sample> GetSamplesByStatusSearch(string statusDescription);
        void LoadData();

    }
    public class SampleRepository : BaseRepository, ISampleRepostitory
    {
        public SampleRepository(FTDNAContext context) : base("Samples.txt",context)
        {
        }

        /// <summary>
        ///  Returns all Samples
        /// </summary>
        /// <returns>List of Samples</returns>
        public List<Sample> GetAllSamples()
        {
            var sampleList = context.Samples
                                    .Include(s => s.User)
                                    .Include(s => s.Status)
                                    .ToList();
            return sampleList;
        }

        public void Add(Sample sample)
        {
            int maxSampleId = context.Samples.Max(s => s.SampleId) + 1;
            sample.SampleId = maxSampleId;
            context.Samples.Add(sample);
            context.SaveChanges();
        }

        /// <summary>
        /// REturns a list of sample that have the status passed in the parameter
        /// </summary>
        /// <param name="statusDescription">Status description</param>
        /// <returns>List of Samples</returns>
        public List<Sample> GetSamplesByStatusSearch(string statusDescription)
        {
            var sampleList = context.Samples
                                  .Include(s => s.User)
                                  .Include(s => s.Status)
                                  .Where(s => s.Status.StatusDescription == statusDescription)
                                  .ToList();

            return sampleList;
        }

        /// <summary>
        /// Returns a list of Sample for created by Users that contain the search string in their name
        /// </summary>
        /// <param name="userNameSearchString">string used to search for User Name</param>
        /// <returns>List of Samples</returns>
        public List<Sample> GetSampleByUserNameSearch(string userNameSearchString)
        {
            var sampleList = context.Samples
                                         .Include(s => s.Status) 
                                         .Include(s => s.User)
                                         .Where(s => s.User.FirstName.Contains(userNameSearchString) || s.User.LastName.Contains(userNameSearchString))
                                         .ToList();
            return sampleList;
        }

        public override void LoadData()
        {
            if (!context.Samples.Any())
            {
                var readCsv = File.ReadAllText(base.filePath);

                string[] records = readCsv.Split('\n');
                for (int i = 0; i < records.Count(); i++)
                {
                    if (i != 0)//ignore the first record
                    {
                        var record = records[i].TrimEnd('\r');

                        var splitResults = record.Split(',');

                        if (splitResults.Count() == 5) //make sure its a valid record read from the text file
                        {
                            Sample sample = new Sample
                            {
                                SampleId = int.Parse(splitResults[0]),
                                Barcode = splitResults[1],
                                CreatedAt = DateTime.Parse(splitResults[2]),
                                CreatedBy = int.Parse(splitResults[3]),
                                StatusId = int.Parse(splitResults[4])
                            };

                            base.context.Samples.Add(sample);
                        }
                    }
                }

                base.context.SaveChanges();
            }
        }

    }
}
