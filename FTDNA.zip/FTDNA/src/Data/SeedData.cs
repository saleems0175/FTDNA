﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Data.Models;
using Data.Repositories;

namespace Data
{
    public class SeedData
    {
        IUserRepository _userRepository;
        IStatusRepository _statusRepository;
        ISampleRepostitory _sampleRepository;
        public SeedData(IUserRepository userRepository, ISampleRepostitory sampleRepository, IStatusRepository statusRepository)
        {
            _userRepository = userRepository;
            _statusRepository = statusRepository;
            _sampleRepository = sampleRepository;
        }

        public void LoadData()
        {
            _userRepository.LoadData();
            _statusRepository.LoadData();
            _sampleRepository.LoadData();
        }
    }
}
