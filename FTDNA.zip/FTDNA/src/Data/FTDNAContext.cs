﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Data.Models;

namespace Data
{
    public class FTDNAContext : DbContext
    {
        private IConfigurationRoot _config;
        public FTDNAContext(IConfigurationRoot config, DbContextOptions options) : base(options)
        {
            _config = config;
        }
        public virtual DbSet<Sample> Samples { get; set; }
        public virtual DbSet<Status> Status { get; set; }
        public virtual DbSet<User> Users { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            base.OnConfiguring(optionsBuilder);
            optionsBuilder.UseSqlServer(_config["ConnectionStrings:FTDNAContextConnection"]);
        }

    }
}
