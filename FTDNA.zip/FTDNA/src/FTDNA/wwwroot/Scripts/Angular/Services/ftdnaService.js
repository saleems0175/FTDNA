﻿angular.module('ftdnaApp').service('ftdnaService', ['$http', '$httpParamSerializer', function ($http, $httpParamSerializer) {


    this.GetAllSamples = function () {
        return $http.post('/Home/GetAllSamples');
    }

    this.GetSampleByUserNameSearch = function (userNameSearchString) {
        return $http.post('/Home/GetSampleByUserNameSearch/', { UserNameSearchString: userNameSearchString });
    }

    this.GetSamplesByStatusSearch = function (statusDescription) {
        return $http.post('/Home/GetSamplesByStatusSearch', { statusDescription: statusDescription });
    }

    this.CreateSample = function (sampleObject) {
        //return $http.post('/Home/CreateSample', JSON.stringify({ sample: sampleObject }));
        return $http.post('/Home/CreateSample', sampleObject );
        //return $http.post('/Home/CreateSample', { Barcode: sampleObject.Barcode, CreatedBy: sampleObject.CreatedBy, StatusId : sampleObject.StatusId, CreatedAt: sampleObject.CreatedAt });
    }

}])