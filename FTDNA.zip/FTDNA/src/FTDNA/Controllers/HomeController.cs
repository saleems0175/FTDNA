﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Data.Models;
using Data.Repositories;
using System.Net;

namespace FTDNA.Controllers
{
    public class HomeController : Controller
    {
        private ISampleRepostitory _sampleRepository;
        private IUserRepository _userRepository;
        private IStatusRepository _statusRepository;
        public HomeController(ISampleRepostitory sampleRepository, IStatusRepository statusRepository, IUserRepository userRepository)
        {
            _sampleRepository = sampleRepository;
            _statusRepository = statusRepository;
            _userRepository = userRepository;
        }
        public IActionResult Index()
        {
            var userList = _userRepository.GetAllUsers();

            //get list of Statuses
            var statusList = _statusRepository.GetAllStatuses();

            ViewBag.userList = userList.ToDictionary(u => u.UserId, u => u.FirstName + " " + u.LastName);
           
            ViewBag.statusList = statusList.ToDictionary(s => s.StatusId, s => s.StatusDescription);

            return View();
        }

        public JsonResult GetAllSamples()
        {
            var samplesList = _sampleRepository.GetAllSamples();

            return Json(samplesList);
        }

        public JsonResult GetSampleByUserNameSearch([FromBody]User user)
        {
            var sampleList = _sampleRepository.GetSampleByUserNameSearch(user.UserNameSearchString);
            return Json(sampleList);
        }

        public JsonResult GetSamplesByStatusSearch([FromBody]Status status)
        {
            var sampleList = _sampleRepository.GetSamplesByStatusSearch(status.StatusDescription);
            return Json(sampleList);
        }

        [HttpPut]
        public JsonResult CreateSample([FromBody]Sample sample)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    _sampleRepository.Add(sample);
                    return Json(new { success = true, status = HttpStatusCode.OK });
                }
                else
                {
                    Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                    return Json(new { sucess = false, error = "Model State Validation failed" });
                }
            }
            catch (Exception ex)
            {
                Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                return Json(new { sucess = false, error = ex.Message });
            }
        }

    }
}

